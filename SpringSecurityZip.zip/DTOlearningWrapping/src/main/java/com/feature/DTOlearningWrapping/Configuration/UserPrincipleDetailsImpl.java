package com.feature.DTOlearningWrapping.Configuration;

import java.util.Collection;
import java.util.Collections;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.feature.DTOlearningWrapping.Entity.Users;
import com.feature.DTOlearningWrapping.Utilities.Utility;

public class UserPrincipleDetailsImpl implements UserDetails{
	
	private Users user;
	UserPrincipleDetailsImpl(Users userObj)
	{
		this.user=userObj;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		Byte role=user.getRole();
		return Collections.singleton(new SimpleGrantedAuthority((Utility.roleMapper(role))));
	}

	@Override
	public String getPassword() {
		return user.getPassword();
	}

	@Override
	public String getUsername() {
		return user.getEmailId();
	}

}
