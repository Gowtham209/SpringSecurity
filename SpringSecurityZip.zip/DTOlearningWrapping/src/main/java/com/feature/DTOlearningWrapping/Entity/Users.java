package com.feature.DTOlearningWrapping.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Users {
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
    public Byte getRole() {
		return role;
	}
	public void setRole(Byte role) {
		this.role = role;
	}
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userId;
    private String userName;
    private String emailId;
    private String password;
    private Byte role;
	@Override
    public  String toString()
    {
        return "Users\n[ userID:"+userId+" , userName:"+userName+" , emailID:"+emailId+" , role:"+role+" ]\n";
    }

}
