package com.feature.DTOlearningWrapping.Controller;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.feature.DTOlearningWrapping.Configuration.JwtService;
import com.feature.DTOlearningWrapping.DTO.UsersDTO;
import com.feature.DTOlearningWrapping.Entity.Users;
import com.feature.DTOlearningWrapping.Service.UserService;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("api")
public class FeatureController {
	
    @Autowired
    private ModelMapper modelMapper;
    @Autowired
    private UserService userService;
    @Autowired
    private AuthenticationManager authManagerObj;
    
    @Autowired
    private JwtService jwtObj;
    
    @PostMapping("/login")
    public String loginVerification(@RequestBody Users userObj)
    {
    	Authentication authenticationObj=authManagerObj.authenticate(
    			new UsernamePasswordAuthenticationToken(userObj.getEmailId(),userObj.getPassword())); 
    	/*
    	The Above Code calls the "public AuthenticationProvider authProvider()" method in "class ProjectSecurityConfig"

    	* */
        if(authenticationObj.isAuthenticated())
    	{
    		String token=jwtObj.generateJwtToken(userObj.getEmailId());
    		return token;
    	}
    	return "Error";
    }

    @PostMapping("/signup")
    public UsersDTO addNewUser(@RequestBody UsersDTO usersDtoObj)
    {
        Users user = modelMapper.map(usersDtoObj, Users.class);
        Users userCreated = userService.createNewUsers(user);
        UsersDTO responseObj=modelMapper.map(userCreated,UsersDTO.class);
        return responseObj;
    }
    

    @GetMapping("/csrf/token")
    public CsrfToken getToken(HttpServletRequest request)
    {
    	return (CsrfToken) request.getAttribute("_csrf");
    }
    
    @GetMapping("/test")
    public String apiTest()
    {
    	return "Works";
    }
    @GetMapping("/test1")
    public String apiTest1()
    {
    	return "new page";
    }

    
    @PutMapping("/user/{userId}")
    public UsersDTO updateUser(@RequestBody UsersDTO userDtoObj)
    {
    	Users userObj=modelMapper.map(userDtoObj,Users.class);
    	Users updatedUserObj=userService.updateUser(userObj);
    	UsersDTO reponseObj = modelMapper.map(updatedUserObj, UsersDTO.class);
    	
    	return reponseObj;
    }
    
    @DeleteMapping("/user/{userId}")
    public void deleteUser(@PathVariable("userId") Long userId)
    {
    	
    	userService.deleteUser(userId);
    }
    
    @GetMapping("/all/users")
    public List<UsersDTO> getAllUsers()
    {
    	List<Users> lst=userService.getAllUsers();
    	List<UsersDTO> DtoLst=new ArrayList<>();
    	for(Users obj:lst)
		{
			DtoLst.add(modelMapper.map(obj, UsersDTO.class));
		}
    	return DtoLst;
    }
    
  /*  @PostMapping("/newUser")
    public User addNewUser(@RequestBody User usersDtoObj)
    {
        System.out.println("Hitted Controller -> AddNewUser");
        System.out.println(usersDtoObj);

//        User user = modelMapper.map(usersDtoObj, User.class);
//
//        User userCreated = userService.createNewUsers(user);
//
//        UserDTO responseObj=modelMapper.map(userCreated,UserDTO.class);

        return usersDtoObj;
    }*/

    @GetMapping("/user/{userId}")
    public UsersDTO getUser(@PathVariable("userId") Long userId)
    {
        System.out.println("Hitted Controller -> getUser "+userId);
        Users obj=userService.getUsers(userId);
        UsersDTO response=modelMapper.map(obj,UsersDTO.class);
        return response;
    }

}
