package com.feature.DTOlearningWrapping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DtOlearningWrappingApplicationTests {

	@Test
	void contextLoads() {
	}

}
