package com.feature.DTOlearningWrapping.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.feature.DTOlearningWrapping.DTO.UsersDTO;
import com.feature.DTOlearningWrapping.Entity.Users;
import com.feature.DTOlearningWrapping.Repository.UsersRepo;
import com.feature.DTOlearningWrapping.Utilities.Utility;


@Service
public class UserService {
	@Autowired
    private UsersRepo userRepo;
	private BCryptPasswordEncoder encoder= new BCryptPasswordEncoder(12);

    public Users createNewUsers(Users user)
    {
        System.out.println("Hitted UsersService -> createdNewUsers");
        System.out.println(user);
        user.setPassword(encoder.encode(user.getPassword()));
        Users obj=userRepo.save(user);
        return obj;
    }
    
    public Users passwordUpdate(Users userObj)
    {
    	userObj.setPassword(encoder.encode(userObj.getPassword()));
    	Long userId = userObj.getUserId();
		
		Utility utilObj = new Utility();
		Users response=utilObj.updateUser(userId, userObj);
		System.out.println("Updated:"+response);
		
		
		return response;
    	
    }

    public Users getUsers(Long userId)
    {
        System.out.println("Hitted UsersService -> getUsers "+userId);

        Users obj=userRepo.findById(userId).orElse(null);

        return obj;
    }

	public Users updateUser(Users userObj) {
		Long userId = userObj.getUserId();
		
		Utility utilObj = new Utility();
		Users response=utilObj.updateUser(userId, userObj);
		
		
		return response;
	}
	
	public void deleteUser(Long userId)
	{
		userRepo.deleteById(userId);
	}

	public List<Users> getAllUsers() {
		
		List<Users> lst = userRepo.findAll();
	
		return lst;
	}
}
